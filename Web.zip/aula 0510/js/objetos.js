// OBJETO MATH

let numero = 789.876277484839;
console.log(numero, typeof numero);

// arredondamento de numeros
// 1- arredondamnto para o proximo inteiro
console.log(Math.ceil(numero));

// 2- arredondamnto para o inteiro anterior (proprio inteiro- so tira as casas decimais)
console.log(Math.floor(numero));
//Math.round() 
// - se casa decimal for entre 0 e 49 ele vai retornar o proprio inteiro
// - se casa decimal for entre 50 e 99 ele vai retornar o proprio inteiro
console.log(Math.round(numero));
console.log('------------------');

// sortear numeros - numeros entre 0 e 1 ele retorna para decimal
let numeroSorteado = Math.random();
console.log(numeroSorteado);

// exemplo: sortear um numero de 0 e 30 ele retorna numero inteiro mas com casas decimais
numeroSorteado = Math.random()*31;
console.log(numeroSorteado);

// checkpoint 5
// exemplo: sortear um numero de 0 e 30 SEM DECIMAIS
numeroSorteado= Math.floor(Math.random()*31);
console.log(numeroSorteado);


// ARRAY
// declarando array
const pessoas = ['eu', 'tu', 'ele', 'nos', 'vos', 'eles'];
console.log(pessoas);
// pegar qual posicao eu quero mostrar dentro do array - contagem comeca do 0
console.log(pessoas[2])

// inserir novos elementos no array - inserir conteudo apos ultimo indice
pessoas.push('Princesa');
console.log(pessoas);
pessoas.push('Rainha');
console.log(pessoas);

// excluir o ultimo indice - cuidado pois ele apaga mesmo
pessoas.pop();
console.log(pessoas);

// excluir e passar dentro de uma variavel
let retirado = pessoas.pop()
console.log(pessoas);
console.log(retirado);

// inserir novos elementos no array - inserir conteudo no inicio do array; antes do primeiro indice
pessoas.unshift('Naomi')
console.log(pessoas)
pessoas.unshift('Virgini')
console.log(pessoas)

// excluir o primeiro indice
pessoas.shift();
console.log(pessoas);

// excluir e passar para uma variavel
retirado = pessoas.shift();
console.log(pessoas);
console.log(retirado);

// inserir ou excluir em qq parte do array
// excluir - definir onde começar a exclusao e quantos serao excluidos
console.log(pessoas);
// definir onde comeca e quantas casas no total ele exclui
pessoas.splice(2,2)
console.log(pessoas);
pessoas.splice(2,3)
console.log(pessoas);

// inserir - definir onde comeca, numeros de exclusoes (pode ser 0), conteudo
pessoas.splice(2,0, 'ele', 'nos', 'eu mesmo', 'voce', 'todo mundo')
console.log(pessoas);

// gerar array com 20 numeros entre 0 e 40
// somar os valores do array
let total = 0;

const numeros=[];
for(let i=0; i<=19; i++){
  numeros.push(Math.floor(Math.random()*41));
  total += numeros[i];
}

console.log(numeros)
console.log(total)

// usando o array pessoas eu posso sortear 3
console.log(pessoas)
for(let i=0; i<=2; i++){
   let pessoaSorteada=Math.floor(Math.random()*9);
   console.log(pessoas[pessoaSorteada]);
}







